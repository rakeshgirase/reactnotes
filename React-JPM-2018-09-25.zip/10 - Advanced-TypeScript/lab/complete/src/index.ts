import Calculator from './calculator';
import wireup from './wireup';

const calculator = new Calculator();
console.log(calculator.multiply(2, 5));
wireup(calculator);
